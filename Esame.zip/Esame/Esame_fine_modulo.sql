-- Creazione DB
CREATE DATABASE ToysGroupDB;

-- Indichiamo di voler usare il db appena creato
use ToysGroupDB;

-- Creiamo in sequenza Prodotti, Regioni e Vendite

-- Creiamo la tabella prodotti

CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(30),
    Category VARCHAR(30)
);

-- Creiamo la tabella Regioni

CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(30)
);

-- CREAZIONE tabella Vendite 

CREATE TABLE Sales (
    SalesID INT PRIMARY KEY,
    ProductID INT,
    RegionID INT,
    SalesDate DATE,
    Quantity INT,
    Price Decimal(10,2),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

-- Iniziamo il popolamento delle tabelle 

-- Popoliamo l'anagrafica Prodotti/categorie

INSERT INTO Product (ProductID, ProductName, Category) VALUES
(1, 'Ferrari', 'modellismo'),
(2, 'Lamborghini', 'modellismo'),
(3, 'KTM', 'modellismo'),
(4, 'Topolino', 'Disney'),
(5, 'Paperino', 'Disney'),
(6, 'Pluto', 'Disney'),
(7, 'Passeggino', 'Bimbe'),
(8, 'Cucina', 'Bimbe'),
(9, 'Lego', 'Bimbi'),
(10, 'Ruspa', 'Bimbi');

-- Popoliamo l'anagrafica Regioni

INSERT INTO Region (RegionID, RegionName) VALUES
(1, 'Italia'),
(2, 'Belgio'),
(3, 'Spagna'),
(4, 'Svizzera'),
(5, 'Francia'),
(6, 'Svezia');

-- Popoliamo la tabella vendita, per pratcità ho ipotizato che l'azienda non fosse un B2C ma un B2B per avere dati più significativi

INSERT INTO Sales (SalesID, ProductID, RegionID, SalesDate, Quantity, Price) VALUES
(1, 3, 1, '2024-01-15', 15, 20.00),
(2, 5, 2, '2024-01-20', 20, 15.00),
(3, 3, 3, '2024-01-25', 30, 30.00),
(4, 6, 2, '2024-02-01', 50, 20.00),
(5, 9, 1, '2024-02-05', 90, 30.00),
(6, 7, 4, '2024-02-10', 20, 45.00),
(7, 4, 5, '2024-02-15', 30, 25.00),
(8, 4, 6, '2024-02-20', 50, 10.00),
(9, 3, 1, '2024-03-01', 70, 35.00),
(10, 10, 2, '2024-03-05', 10, 50.00),
(11, 1, 3, '2024-03-10', 33, 60.00),
(12, 1, 4, '2024-03-15', 14, 40.00),
(13, 1, 5, '2024-03-20', 78, 15.00),
(14, 3, 6, '2024-03-25', 180, 30.00),
(15, 5, 1, '2024-04-01', 10, 45.00),
(16, 8, 2, '2024-04-05', 80, 25.00),
(17, 7, 3, '2024-04-10', 10, 10.00),
(18, 8, 4, '2024-04-15', 278, 35.00),
(19, 3, 5, '2024-04-20', 156, 50.00),
(20, 6, 1, '2024-04-01', 756, 45.00),
(21, 6, 2, '2024-04-05', 18, 25.00),
(22, 6, 3, '2024-04-10', 190, 10.00),
(23, 7, 4, '2024-04-15', 80, 35.00),
(24, 1, 5, '2024-04-20', 70, 50.00),
(25, 8, 6, '2024-04-25', 20, 60.00),
(26, 6, 6, '2023-06-05', 79, 10.00),
(27, 7, 1, '2023-07-10', 187, 35.00),
(28, 8, 2, '2023-08-15', 12, 50.00),
(29, 9, 3, '2023-09-20', 130, 60.00),
(30, 1, 4, '2023-10-25', 170, 40.00),
(31, 3, 5, '2023-11-30', 150, 15.00),
(32, 3, 6, '2023-12-05', 170, 30.00),
(33, 1, 1, '2023-01-10', 89, 20.00),
(34, 5, 2, '2023-02-15', 78, 15.00),
(35, 3, 3, '2023-03-20', 22, 30.00),
(36, 4, 4, '2023-04-25', 49, 45.00),
(37, 5, 5, '2023-05-30', 73, 25.00);

/* Verifica unicità ProductID , 
 con questa query verifichiamo che ogni product id non si ripeta due volte
(avendola indicata come primary key in fase di popolamento avremmo avuto un errore in caso di non unicità)*/
SELECT ProductID, COUNT(*)
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1;


-- Verifica unicità RegionID
SELECT RegionID, COUNT(*)
FROM Region
GROUP BY RegionID
HAVING COUNT(*) > 1;



-- Verifica unicità SalesID
SELECT SalesID, COUNT(*)
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) > 1;

-- 2 Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.  
Create view Fatturato_Prodotti_Anno as (SELECT
    P.ProductName,
    YEAR(S.SalesDate) AS Year,
    SUM(S.Quantity * S.Price) AS TotalRevenue
FROM
    Sales S
    JOIN Product P ON S.ProductID = P.ProductID
GROUP BY
    P.ProductName,
    YEAR(S.SalesDate));
    
    SELECT * FROM FATTURATO_PRODOTTI_ANNO
    
-- 3. Esporre il fatturato totale per regione per anno, ordinando il risultato per data e per fatturato decrescente

Create view Fatturato_per_regione AS (SELECT
    R.RegionName,
    YEAR(S.SalesDate) AS Year,
    SUM(S.Quantity * S.Price) AS TotalRevenue
FROM
    Sales S
    JOIN Region R ON S.RegionID = R.RegionID
GROUP BY
    R.RegionName,
    YEAR(S.SalesDate)
ORDER BY
    YEAR(S.SalesDate),
    TotalRevenue DESC);
    
    
    select * from Fatturato_per_regione ;
    
-- 4. Qual è la categoria di articoli maggiormente richiesta dal mercato? (ho inteso come PEZZI VENDUTI)
Create view Categoria_più_richiesta As (SELECT
    P.Category,
    SUM(S.Quantity) AS Total_quantity_sales
FROM
    Sales S
    JOIN Product P ON S.ProductID = P.ProductID
GROUP BY
    P.Category
ORDER BY
    Total_quantity_sales DESC
LIMIT 1);

select * from categoria_più_richiesta;


-- 5. Quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti
-- 1: Utilizzare una subquery 

Create View Prodotti_invenduti_1 as (SELECT
    P.ProductName
FROM
    Product P
WHERE
    P.ProductID NOT IN (
        SELECT S.ProductID
        FROM Sales S
    ));
    
    select * from prodotti_invenduti_1;
    
    
--     Approccio 2: Utilizzare un LEFT JOIN (il risultato è Cane Pow Patrol)


Create view Prodotti_invenduti_2 as (SELECT
    P.ProductName
FROM
    Product P
    LEFT JOIN Sales S ON P.ProductID = S.ProductID
WHERE
    S.SalesID IS NULL);
    
select* from prodotti_invenduti_2;

-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente)
Create view Data_ultima_vendita As (SELECT
    P.ProductName,
    MAX(S.SalesDate) AS LastSaleDate
FROM
    Sales S
    JOIN Product P ON S.ProductID = P.ProductID
GROUP BY
    P.ProductName);
    select * from data_ultima_vendita